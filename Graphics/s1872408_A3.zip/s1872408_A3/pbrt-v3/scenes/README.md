pbrt example scene
==================

This file contains a single example scene, ``killeroo-simple``, which is
mentioned in the exercise at the end of Chapter 1.  For many more scenes
(that are also much more interesting), see the [pbrt-v3 scenes
page](http://pbrt.org/scenes-v3.html) on the pbrt website.
